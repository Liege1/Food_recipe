public class Recipe {
    package com.example.recipeapp.model

    data class Recipe(
            val title: String,
            val mealType: String,
            val serves: Int,
            val difficultyLevel: String,
            val ingredients: List<String>,
            val preparationSteps: List<String>
    )

}
